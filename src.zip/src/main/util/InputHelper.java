package main.util;

public class InputHelper {
}
