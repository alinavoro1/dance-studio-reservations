package main.service;

public class AbonamentService {
}
