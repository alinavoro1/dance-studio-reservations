package main.service;

public class ProfesorService {
}
