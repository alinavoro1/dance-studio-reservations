package main.model;

import java.util.List;

public class Client extends Persoana{
    private Abonament abonament;
    private List<Rezervare> rezervari;
}
