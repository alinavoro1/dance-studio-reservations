package main.model;

import java.time.LocalDateTime;

public class Rezervare {
    private static int id;
    private Client client;
    private ClasaDans clasa;
    private LocalDateTime dataRezervare;
    private boolean activa;
}
