package main.model;

import java.time.LocalDateTime;

public class Plata {
    private int id;
    private Client client;
    private double suma;
    private LocalDateTime data;
    private String metoda; // card / cash
}
