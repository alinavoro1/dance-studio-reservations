package main.model;
import java.time.LocalDate;

public class Abonament {
    private static int id;
    private double pret;
    private LocalDate dataStart;
    private LocalDate dataExpirare;
    private int numarLuni;
    private int numarClase;
}
