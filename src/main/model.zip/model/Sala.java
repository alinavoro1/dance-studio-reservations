package main.model;

public class Sala {
    private static int id;
    private String nume;
    private int capacitate;
    private String locatie;
}
