package main.model;

import java.time.DayOfWeek;
import java.time.LocalTime;

public class Program {
    private DayOfWeek zi;
    private LocalTime oraStart;
    private LocalTime oraFinal;
}
