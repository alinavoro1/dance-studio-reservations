package main.model;

public class AbonamentGold {
    private int sedinteRamase;
}
