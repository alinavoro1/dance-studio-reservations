package main.model;

import java.util.List;

public class Profesor {
    private String specializare;
    private double salariu;
    private List<ClasaDans> clase;
}
