package main.model;

import java.util.List;

public class ClasaDans {
    private static int id;
    private String nume;
    private StilDans tip;
    private Profesor profesor;
    private Sala sala;
    private Program program;
    private List<Rezervare> rezervari;
}
