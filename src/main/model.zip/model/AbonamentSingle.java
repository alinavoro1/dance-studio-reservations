package main.model;

public class AbonamentSingle {
    private Boolean folosit;
}
