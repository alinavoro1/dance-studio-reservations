package main.model;

public class AbonamentSilver {
    private int sedinteRamase;
}
