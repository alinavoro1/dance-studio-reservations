package main.model;

public class Persoana {
    private static int id;
    private String nume;
    private String email;
    private String telefon;

}
