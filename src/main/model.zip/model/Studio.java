package main.model;
import java.util.List;

public class Studio {
    private String nume;
    private String locatie;
    private List<Sala> sali;
    private List<Profesor> profesori;
}
